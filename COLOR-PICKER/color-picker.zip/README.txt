A Pen created at CodePen.io. You can find this one at http://codepen.io/voronianski/pen/zpahm.

 easy color picker with jquery